#include "ApplicationManager.h"
#include "Actions\AddRectAction.h"
#include "AddSquareAction.h"
#include"AddTriangleAction.h"
#include"AddHexaAction.h"
#include"AddCircleAction.h"
#include "SelectAction.h"
#include"switchplyAction.h"
#include"switchdrwAction.h"
#include"shapeAction.h"
#include"eraseAction.h"
#include"RecordingAction.h"
#include"Clearall.h"
#include"PlayRecordingAction.h"
#include "FillColorAction.h"
#include "DrwColorAction.h"
#include <cmath>

bool Action::fill = false;

//Constructor
ApplicationManager::ApplicationManager()
{
	//Create Input and output
	pOut = new Output;
	pIn = pOut->CreateInput();
	
	FigCount = 0;
	actioncount = 0;// intialize the numbers of actions that has been done
	SelectedFig = NULL;
	//Create an array of figure pointers and set them to NULL		
	for (int i = 0; i < MaxFigCount; i++)
	{
		FigList[i] = NULL;
	}
	//Create an array of actiontype pointers and set them to NULL	
	for (int i = 0; i < MaxActionCount; i++)
	{
		actions[i] = NULL;
	}
}

//==================================================================================//
//								Actions Related Functions							//
//==================================================================================//
ActionType ApplicationManager::GetUserAction() const
{
	//Ask the input to get the action from the user.
	return pIn->GetUserAction();		
}
////////////////////////////////////////////////////////////////////////////////////
//Creates an action and executes it
void ApplicationManager::ExecuteAction(ActionType ActType) 
{
	Action* pAct = NULL;
	
	//According to Action Type, create the corresponding action object
	switch (ActType)
	{
	    case Select:
		    pAct = new SelectAction(this);
		    break;
		case DRAW_RECT:
			pAct = new AddRectAction(this);
			break;
		case SQUARE:
			pAct = new AddSquareAction(this);
			break;
		case Triangle:
			pAct = new AddTriangleAction(this);
			break;
		case HEXA:
			pAct = new AddHexaAction(this);
			break;
		case CIRCLE:
			pAct = new AddCircleAction(this);
			break;
		case PLAY:
			{
			pAct = new switchplyAction(this);
			break;
			}
		case shape:
		{ pAct = new shapeAction(this);
		      break;
		}
		case draw:
		{
			pAct = new switchdrwAction(this);
			break;
		}
		case ERASE:
		{
			pAct = new eraseAction(this);
			break;
		}
		case RECORD:
		{
			int count_action=0;         //for checking if all actions are null like we start our program or after clear all function
			int count_figure = 0;       //for checking if all figures are null like we start our program or after clear all function
			for (int i = 0; i < MaxActionCount; i++)
			{
				if (actions[i] == NULL)
					count_action++;// increasing numbers of actions of NULL
			}
			for (int i = 0; i < MaxFigCount; i++)
			{
				if (FigList[i] == NULL)
					count_figure++; // increasing number of fig_list of NULL
			}
			if (count_figure == MaxFigCount && count_action == MaxActionCount)       //if all are NULL we will do the record
			{
				pAct = new RecordingAction(this);
				break;
			}
			else { pOut->PrintMessage(" ERROR: Record action only  can be used after clearall or in the start of program"); } //ERROR message
			break;
		}
		case STOPRECORD:
		{
			pOut->PrintMessage(" ERROR: this function only works when you use record action");   // cant stop record for a non existing record
			break;
		}
		case Delete:
		{
			pAct = new Clearall(this);
			break;
		}
		case PLAYREC:
		{
			pAct = new PlayRecordingAction(this);
			break;
		}
		case FILLCOLOUR:
		{
			pAct = new FillColorAction(this);
			break;
		}	
		case PENCIL:
		{
			pAct = new DrwColorAction(this);
			break;
		}
		case EXIT:
			return;
		case DRAWING_AREA:
			return;
		case STATUS:	//a click on the status bar ==> no action
			return;
	}
	
	//Execute the created action
	if(pAct != NULL)
	{
		pAct->Execute();//Execute
		delete pAct;	//You may need to change this line depending to your implementation
		pAct = NULL;
	}
	
}
//==================================================================================//
//						Figures Management Functions								//
//==================================================================================//

//Add a figure to the list of figures
void ApplicationManager::AddFigure(CFigure* pFig)
{
	if(FigCount < MaxFigCount )
		FigList[FigCount++] = pFig;	
}
////////////////////////////////////////////////////////////////////////////////////
CFigure *ApplicationManager::GetFigure(Point p) const
{
	//If a figure is found return a pointer to it.
	//if this point (x,y) does not belong to any figure return NULL


	for (int i = FigCount-1; i >=0; i--)
	{
		if (FigList[i]->isThisFigure(p)) return FigList[i];
	}

	//Add your code here to search for a figure given a point x,y	
	//Remember that ApplicationManager only calls functions do NOT implement it.

	return NULL;
}
 int ApplicationManager::GetNUMfig(Point p) 
{
	//If a figure is found return a pointer to it.
	//if this point (x,y) does not belong to any figure return NULL


	for (int i =FigCount-1; i>=0 ; i--) {
		if (FigList[i]->isThisFigure(p)) return i;
	}

	//Add your code here to search for a figure given a point x,y	
	//Remember that ApplicationManager only calls functions do NOT implement it.

	return NULL;
}
bool ApplicationManager::CheckSelection(Point p) const
{
	if (SelectedFig == GetFigure(p)&& GetFigure(p)!=NULL&& SelectedFig!=NULL) return true;
	return false;
}
void ApplicationManager::SetSelectedFig(Point p)
{
	SelectedFig = GetFigure(p);
	SelectedFig->SetSelected(true);
}
void ApplicationManager::UnSelectFig()
{
	if (SelectedFig != NULL) 
	{
		SelectedFig->SetSelected(false);
		SelectedFig = NULL;
	}
}
void ApplicationManager::PrintSelectedInfo() const
{
	if (SelectedFig != NULL)
		SelectedFig->PrintInfo(pOut);
}
int ApplicationManager::GetFigCount()
{
	return FigCount;
}

CFigure* ApplicationManager::Getshape(int id)
{
	return FigList[id];
}

void ApplicationManager::deleteshape(Point p)
{
	int x = GetNUMfig(p);
	if (FigList[x]->IsSelected()) //to check if it selected or not for error handling
	{
		UnSelectFig();
	}
	delete FigList[x];
	FigList[x] = NULL;
	// Shift elements in the array to close the gap after deletion
	for (int i = x; i < FigCount - 1; ++i) {
		FigList[i] = FigList[i + 1];
	}
	FigList[GetFigCount() - 1] = NULL; // Clear the last element
	FigCount--;
	pOut->ClearDrawArea();
	UpdateInterface();
}

int ApplicationManager::numgivenkeyshape(char c)
{
	int k = 0;       // in this loop i want to know number of shapes in figlist that choosen random from play mode
	for (int i = 0; i < FigCount; i++)
		if (FigList[i] != NULL)
			if (FigList[i]->keyshape() == c)
				k++;
	return k;

}

void ApplicationManager::Addaction(ActionType* action)
{
	if (actioncount < MaxActionCount)
	{
		actions[actioncount++] = action;  //increasing number of actions in array
	}
}

void ApplicationManager::clearall()
{
	for (int i = 0; i < FigCount; i++) //delete all figures and set them to NULL
	{
		if (FigList[i]!=NULL)
		{
			delete FigList[i];
			FigList[i] = NULL;
		}
	}
	UnSelectFig();  // to delete selection for any figure 
	for (int i = 0; i < actioncount; i++) //delete all actions and set them to NULL
	{
		if (actions[i] != NULL)
		{
			delete actions[i];
			actions[i] = NULL;
		}
	}
	actioncount = 0;                    //the actions beame zero
    FigCount=0;                         //the figures beame zero
	pOut->ClearDrawArea();
	pOut->PrintMessage("The clear all has been done");
}

void ApplicationManager::displayAction()
{
	pOut->PrintMessage("we will start to play record and we will clear all the draw area ");
	Sleep(1000);                                 // only to see the above message
	for (int i = 0; i < FigCount; i++)           //delete all figures and set them to NULL
	{
		if (FigList[i] != NULL)
		{
			delete FigList[i];
			FigList[i] = NULL;
		}
	}
	UnSelectFig();   // to delete selection for any figure 
	pOut->ClearDrawArea();
	FigCount = 0;
	for (int i = 0; i < actioncount; i++)    // display the 
	{
		if (actions[i] != NULL)
		{
			ExecuteAction(*actions[i]);
			UpdateInterface();
		}
		Sleep(1000);           //make a one second sleep between every two operations
	}
	pOut->PrintMessage("The play had been finished and we make "+to_string(actioncount)+" Opeartions");
}

void ApplicationManager::ChngSelectedCLR(char c)
{
	if (c == 'F') SelectedFig->ChngFillClr(pOut->getCrntFillColor());
	if (c=='D')   SelectedFig->ChngDrawClr(pOut->getCrntDrawColor());
}

bool ApplicationManager::ifselected()const
{
	if (SelectedFig == NULL) return false;
	return true;
}



//==================================================================================//
//							Interface Management Functions							//
//==================================================================================//

//Draw all figures on the user interface
void ApplicationManager::UpdateInterface() const
{	
	for (int i = 0; i < FigCount; i++)
	{
		if(FigList[i]!=NULL)
		FigList[i]->Draw(pOut);		//Call Draw function (virtual member fn)
	}
}
////////////////////////////////////////////////////////////////////////////////////
//Return a pointer to the input
Input *ApplicationManager::GetInput() const
{	return pIn; }
//Return a pointer to the output
Output *ApplicationManager::GetOutput() const
{	return pOut; }
////////////////////////////////////////////////////////////////////////////////////
//Destructor
ApplicationManager::~ApplicationManager()
{
	for (int i = 0; i < FigCount; i++)  //delete all figures and set them to NULL
	{
		if (FigList[i] != NULL)
		{
			delete FigList[i];
			FigList[i] = NULL;
		}
	}
	for (int i = 0; i < actioncount; i++)  //delete all actions and set them to NULL
	{
		if (actions[i] != NULL)
		{
			delete actions[i];
			actions[i] = NULL;
		}
	}
	UnSelectFig();
	if(pIn!=NULL)delete pIn; //only for error handling
	if(pOut!=NULL)delete pOut; // only for error handling
	
}
