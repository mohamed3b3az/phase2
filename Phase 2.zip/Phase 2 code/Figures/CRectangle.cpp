#include "CRectangle.h"

CRectangle::CRectangle(Point P1, Point P2, GfxInfo FigureGfxInfo):CFigure(FigureGfxInfo)
{
	Corner1 = P1;
	Corner2 = P2;

}
	

void CRectangle::Draw(Output* pOut) const
{
	//Call Output::DrawRect to draw a rectangle on the screen	
	pOut->DrawRect(Corner1, Corner2, FigGfxInfo, Selected);
}

bool CRectangle::isThisFigure(Point p) const
{
	if (Corner1.y < Corner2.y&&Corner1.x<Corner2.x) {

		if (p.y >= Corner1.y && p.y <= Corner2.y && p.x >= Corner1.x && p.x <= Corner2.x)
			return true;
		else return false;
	}
	else if (Corner1.y < Corner2.y && Corner1.x > Corner2.x) {

		if (p.y >= Corner1.y && p.y <= Corner2.y && p.x <= Corner1.x && p.x >= Corner2.x)
			return true;
		else return false;

	}
	else if (Corner1.y > Corner2.y && Corner1.x < Corner2.x) {

		if (p.y <= Corner1.y && p.y >= Corner2.y && p.x >= Corner1.x && p.x <= Corner2.x)
			return true;
		else return false;
	}
	else {

		if (p.y >= Corner2.y && p.y <= Corner1.y && p.x >= Corner2.x && p.x <= Corner1.x)
			return true;
		else return false;
	}
}

void CRectangle::PrintInfo(Output* pOut)
{
	int width, length;
	if(abs(Corner1.x - Corner2.x) > abs(Corner1.y - Corner2.y))   //Check which is bigger to determine the length & the width
	{
		length = abs(Corner1.x - Corner2.x);
		width = abs(Corner1.y - Corner2.y);
	}
	else {
		length = abs(Corner1.y - Corner2.y);
		width = abs(Corner1.x - Corner2.x);
	}
	string s = "selected Figure Info-->      Type: Rectangle       ID: " + to_string(ID) + "   Center: (" + to_string((Corner1.x+Corner2.x)/2) + "," + to_string((Corner1.y + Corner2.y) / 2) + ")     Length:"
		+ to_string(length)+"     Whidth: "+to_string(width);
	pOut->PrintMessage(s);

}

char CRectangle::keyshape()
{
	return'$';
}