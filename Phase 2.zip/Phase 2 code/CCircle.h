#ifndef CCIRCLE_H
#define CCIRCLE_H
#include "Figures/CFigure.h"
class CCircle : public CFigure
{
private:
	Point Center;
	Point point;
public:
	CCircle(Point, Point, GfxInfo FigureGfxInfo);
	virtual void Draw(Output* pOut) const;
	virtual bool isThisFigure(Point p) const;  // Check is this the selected figure
	virtual void PrintInfo(Output* pOut);	//print all figure info on the status bar
	char keyshape();
};
#endif
