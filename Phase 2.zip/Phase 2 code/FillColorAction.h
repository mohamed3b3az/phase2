#ifndef FILL_ACT
#define FILL_ACT
#include "Actions/Action.h"
class FillColorAction : public Action
{
	ActionType Act;
public:
	FillColorAction(ApplicationManager* pApp);

	//Reads Square parameters
	virtual void ReadActionParameters();

	//Add Sqaure to the ApplicationManager
	virtual void Execute();

};
#endif FILL_ACT
