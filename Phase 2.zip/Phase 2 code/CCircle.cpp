#include "CCircle.h"


CCircle::CCircle(Point P1, Point P2, GfxInfo FigureGfxInfo) :CFigure(FigureGfxInfo)
{
	Center = P1;
	point = P2;
}


void CCircle::Draw(Output* pOut) const
{
	//Call Output::DrawCirc to draw a Circle on the screen	
	pOut->DrawCirc(Center, point, FigGfxInfo, Selected);
}

bool CCircle::isThisFigure(Point p) const
{
	float radius=  sqrt((Center.x - point.x) * (Center.x - point.x) + (Center.y - point.y) * (Center.y - point.y));
	float d= sqrt((Center.x - p.x) * (Center.x - p.x) + (Center.y - p.y) * (Center.y - p.y));

	if (d<=radius)
		return true;
	else return false;
}

void CCircle::PrintInfo(Output* pOut)
{ 
	int  radius = sqrt((Center.x - point.x) * (Center.x - point.x) + (Center.y - point.y) * (Center.y - point.y)); //Determines the Radius of the Circle
	string s = "selected Figure Info-->     Type: Circle      ID: " + to_string(ID) + "   Center: (" + to_string(Center.x) + "," + to_string(Center.y) + ")   radius:"
		+to_string(radius);
	pOut->PrintMessage(s);

}

char CCircle::keyshape()
{
	return '!';
}