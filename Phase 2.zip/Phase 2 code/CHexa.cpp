#include "CHexa.h"

CHexa::CHexa(Point center, GfxInfo FigureGfxInfo): CFigure(FigureGfxInfo)
{
	Center = center;
}

void CHexa::Draw(Output* pOut) const
{
	//Call Output::DrawHexa to draw a Hexagon on the screen	
	pOut->DrawHexa(Center, FigGfxInfo, Selected);
}

bool CHexa::isThisFigure(Point p) const
{
    // Calculate the distance between the point and the hexagon's center
    double dX = abs(p.x - Center.x);
    double dY = abs(p.y - Center.y);

    // Calculate the maximum distance from the center to the hexagon's side
    double maxXD = 100;
    double maxYD = 100* sqrt(3) / 2;

    // Check if the point is within the hexagon bounds
    if (dX <= maxXD) {
        if (dY <= maxYD) {
          if(dX<=100-(sqrt(3.0)/3.0)*dY)
                return true;
        }
    }
    return false;
}

void CHexa::PrintInfo(Output* pOut)
{

	string s = "selected Figure Info-->        Type: Hexagon      ID: " + to_string(ID) + "   Center: (" + to_string(Center.x) + "," + to_string(Center.y) + ")   Length of the side:"
		+ to_string(100);
	pOut->PrintMessage(s);

}

char CHexa::keyshape()
{
	return '@';
}