#ifndef erase_h
#define erase_h
#include"Actions/Action.h"
 
class eraseAction :public Action
{
	Point p;
public:
	eraseAction(ApplicationManager*);
	virtual void  ReadActionParameters();
	virtual void  Execute();

};
#endif

