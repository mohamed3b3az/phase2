#include "CTriangle.h"

CTriangle::CTriangle(Point P1, Point P2,Point P3, GfxInfo FigureGfxInfo) : CFigure(FigureGfxInfo)
{
	Corner1 = P1;	Corner2 = P2;	Corner3 = P3;
	numtriangles++;
}

void CTriangle::Draw(Output* pOut) const
{
	//Call Output::DrawTriang to draw a triangle on the screen	

	pOut->DrawTriang(Corner1, Corner2, Corner3, FigGfxInfo, Selected);
}

bool CTriangle::isThisFigure(Point p) const
{
	float A  = abs(Corner1.x*(Corner2.y-Corner3.y)+Corner2.x*(Corner3.y-Corner1.y)+Corner3.x*(Corner1.y-Corner2.y))/2.0;  //Area of all triangle
	float A1 = abs(p.x * (Corner1.y - Corner2.y) + Corner1.x * (Corner2.y - p.y) + Corner2.x * (p.y - Corner1.y)) / 2.0;  //Area of the first small triangle
	float A2 = abs(p.x * (Corner2.y - Corner3.y) + Corner2.x * (Corner3.y - p.y) + Corner3.x * (p.y - Corner2.y)) / 2.0;  //Area of the second small triangle
	float A3 = abs(p.x * (Corner3.y - Corner1.y) + Corner3.x * (Corner1.y - p.y) + Corner1.x * (p.y - Corner3.y)) / 2.0;  //Area of the third small triangle
	if (A == A1 + A2 + A3) return true; //check is the sum of small areaa = the big area or not
	else return false;
}

void CTriangle::PrintInfo(Output* pOut)
{
	string s = "selected Figure Info-->    Type : Triangle    ID: " + to_string(ID) + "   Center: (" + to_string((Corner1.x + Corner2.x + Corner3.x) / 3) + "," + to_string((Corner1.y + Corner2.y + Corner3.y) / 3)
		+ ")      Corner1: (" + to_string(Corner1.x) + "," + to_string(Corner1.y) + ")      Corner2: (" + to_string(Corner2.x) + "," + to_string(Corner2.y) + ")      Corner3: (" + to_string(Corner3.x) + "," + to_string(Corner3.y) + ")";
	pOut->PrintMessage(s);


}
 
char CTriangle::keyshape()
{
	return '*';
}
int CTriangle::numtriangles = 0;


int CTriangle::getnumshapes()
{
	return numtriangles;
}
