#include "ApplicationManager.h"
#include "GUI/Input.h"
#include "GUI/Output.h"
#include"shapeAction.h"
#include"Figures/CRectangle.h"
#include <random>


shapeAction::shapeAction(ApplicationManager* p):Action(p)
{
	
}

void shapeAction::ReadActionParameters()
{
	//Get a Pointer to the Input / Output Interfaces
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
   
	//Get the point which select the figure
	pIn->GetPointClicked(p1.x, p1.y);
	pOut->ClearStatusBar();
}

void shapeAction::Execute()
{
    Input* pIn = pManager->GetInput();
    Output* pOut = pManager->GetOutput();
    int random_number=0;
    if (pManager->GetFigCount() == 0) {
        pOut->PrintMessage("THERE ARE NO SHAPES TO PICK");
    }
    else  if (pManager->GetFigCount() == 1) 
    {
        pOut->PrintMessage("DRAW MORE SHAPES");
    }
        else if(pManager->GetFigCount()>1)
        {
        
             do
             {
                random_device rd;
                mt19937 gen(rd());
                uniform_int_distribution<> distribution(1, pManager->GetFigCount());
                random_number = distribution(gen);
             } while (pManager->Getshape(random_number) == 0);
                CFigure* shape = pManager->Getshape(random_number);
                if (shape != NULL)
                {
                    char keyShape = shape->keyshape();
                    switch (keyShape)
                    {
                        case '!':
                        { pOut->PrintMessage("Pick all Circle shapes......are you ready click anywhere to start");
                        pIn->GetPointClicked(p1.x, p1.y);
                        break;
                        }
                        case '@':
                        { pOut->PrintMessage("Pick all Hexagonal shapes......are you ready click anywhere to start");
                        pIn->GetPointClicked(p1.x, p1.y);
                        break;
                        }

                        case '#':
                        { pOut->PrintMessage("Pick all Square shapes......are you ready click anywhere to start");
                        pIn->GetPointClicked(p1.x, p1.y);
                        break;
                        }

                        case '*':
                        { pOut->PrintMessage("Pick all Triangle shapes......are you ready click anywhere to start");
                        pIn->GetPointClicked(p1.x, p1.y);
                        break;
                        }
                        case '$':
                        { pOut->PrintMessage("Pick all Rectangle shapes......are you ready click anywhere to start");
                        pIn->GetPointClicked(p1.x, p1.y);
                        break;
                        }
                       
                            
                    }
                }
               pOut->PrintMessage("lets go");
        }
    
    if ( pManager->GetFigCount() > 1)
    {
        char keycharac = (pManager->Getshape(random_number))->keyshape();
        int k = (pManager->numgivenkeyshape(keycharac));
        do
        {
            pIn->GetPointClicked(p1.x, p1.y);
            if (pManager->GetFigure(p1) != 0)
            {
                if ((pManager->GetFigure(p1))->keyshape() == keycharac)
                {
                    pOut->PrintMessage(" GOOD JOB..... IF YOU WANT TO STOP PLAYING CLICK ON ICON STOP PLAY ICON ");
                    pManager->deleteshape(p1);
                    if (pIn->GetUserAction() == stopplay)
                    {
                        pOut->ClearStatusBar();
                        break;
                    }
                    k--;
                    if (k == 0)
                    {
                        pOut->PrintMessage("YOU ARE A CLEVER KID...YOU WIN");
                        break;
                    }
                }
                else
                {
                    pOut->PrintMessage(" FOCUS AND TRY AGAIN ....IF YOU WANT TO STOP PLAYING CLICK ON ICON STOP PLAY ICON ");
                    if (pIn->GetUserAction() == stopplay)
                    {
                        pOut->ClearStatusBar();
                        break;
                    }
                   
                }
                
            }
        } while (1);
    }
     
}

  

   



