#pragma once
#include "Figures/CFigure.h"
class CSquare : public CFigure
{
private :
	Point Center;
public:
	CSquare(Point,int, GfxInfo FigureGfxInfo);
	virtual void Draw(Output* pOut) const;
	virtual bool isThisFigure(Point p) const;  // Check is this the selected figure
	virtual void PrintInfo(Output* pOut);	//print all figure info on the status bar
	char keyshape();
};

