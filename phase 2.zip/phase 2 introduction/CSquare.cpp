#include "CSquare.h"

CSquare::CSquare(Point center,int id, GfxInfo FigureGfxInfo) : CFigure(FigureGfxInfo,id)
{
	Center = center;

}
void CSquare::Draw(Output* pOut) const
{
	//Call Output::DrawSqr to draw a ssquare on the screen	
	pOut->DrawSqr( Center, FigGfxInfo, Selected);
}

bool CSquare::isThisFigure(Point p) const
{
	if ((p.y >= Center.y - 100) && (p.y <= Center.y + 100) && (p.x <= Center.x + 100) && (p.x >= Center.x - 100))
		return true;
	else return false;
}

void CSquare::PrintInfo(Output* pOut)
{
	string s = "selected Figure Info-->      Type: Square         ID: " + to_string(ID) + "   Center: (" + to_string(Center.x) + "," + to_string(Center.y) + ")     Length:"
		+ to_string(100)  ;
	pOut->PrintMessage(s);


}

char CSquare::keyshape()
{ 
	return '#';
}

