#include"switchplyAction.h"
#include "ApplicationManager.h"
#include "GUI/Input.h"
#include "GUI/Output.h"
switchplyAction::switchplyAction(ApplicationManager* p):Action(p)
{

}

void switchplyAction::Execute()
{     
	ReadActionParameters();
}

 void switchplyAction::ReadActionParameters()
{
	 Output* pOut = pManager->GetOutput();
	 pOut->PrintMessage("switch to play mode");
	 pOut->Cleartoolbar();
	 pOut->CreatePlayToolBar();
}