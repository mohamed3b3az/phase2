#include "CHexa.h"

CHexa::CHexa(Point center,int id, GfxInfo FigureGfxInfo): CFigure(FigureGfxInfo,id)
{
	Center = center;
}

void CHexa::Draw(Output* pOut) const
{
	//Call Output::DrawHexa to draw a Hexagon on the screen	
	pOut->DrawHexa(Center, FigGfxInfo, Selected);
}

bool CHexa::isThisFigure(Point p) const
{
		if ((p.y >= Center.y -(sqrt(3)/2)*100) && (p.y <= Center.y + (sqrt(3) / 2) * 100) && (p.x <= Center.x + 100) && (p.x >= Center.x - 100))
			return true;
		else return false;
}

void CHexa::PrintInfo(Output* pOut)
{

	string s = "selected Figure Info-->        Type: Hexagon      ID: " + to_string(ID) + "   Center: (" + to_string(Center.x) + "," + to_string(Center.y) + ")   Length of the side:"
		+ to_string(100);
	pOut->PrintMessage(s);

}

char CHexa::keyshape()
{
	return '@';
}