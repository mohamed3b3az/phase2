#ifndef switchdrwAction_h
#define switchdrwAction_h
#include"Actions/Action.h"

class switchdrwAction :public Action
{


public:
	switchdrwAction(ApplicationManager*);
	virtual void Execute();
	virtual void ReadActionParameters();


};
#endif
