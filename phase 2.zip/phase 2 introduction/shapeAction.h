#ifndef shapeAction_h
#define shapeAction_h
#include"Actions/Action.h"
class shapeAction :public Action
{
protected:
	int fignum;
	Point p1;
public:
	shapeAction(ApplicationManager*);
	virtual void ReadActionParameters();
	virtual void Execute();


};
#endif

