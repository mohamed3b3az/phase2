#include "ApplicationManager.h"
#include "GUI/Input.h"
#include "GUI/Output.h"
#include"eraseAction.h"

eraseAction::eraseAction(ApplicationManager*p):Action(p){}

void eraseAction:: ReadActionParameters()
{
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	pOut->PrintMessage("click the shape you want to delete");
	pIn->GetPointClicked(p.x,p.y);
}

void eraseAction::Execute()
{
	Output* pOut = pManager->GetOutput();
	ReadActionParameters();
	if (pManager->GetFigCount() == 0)
		pOut->PrintMessage("NO SHAPES TO DELETE");
	else if (pManager->GetFigure(p) != 0)
		pManager->deleteshape(p);
	pOut->ClearStatusBar();
}