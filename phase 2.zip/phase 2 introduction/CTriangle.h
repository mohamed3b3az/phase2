#ifndef TRIANG_H
#define TRIANG_H
#include "Figures/CFigure.h"
class CTriangle : public CFigure
{

private:
	Point Corner1;
	Point Corner2;
	Point Corner3;
	static int numtriangles;
public:
	CTriangle(Point, Point,Point,int, GfxInfo FigureGfxInfo);
	virtual void Draw(Output* pOut) const;
	virtual bool isThisFigure(Point p) const;  // Check is this the selected figure
	virtual void PrintInfo(Output* pOut);	//print all figure info on the status bar
	char keyshape();
	static int getnumshapes();
};
#endif
