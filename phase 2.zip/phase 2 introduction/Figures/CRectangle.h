#ifndef CRectangle_H
#define CRectangle_H

#include "CFigure.h"

class CRectangle : public CFigure
{
private:
	Point Corner1;	
	Point Corner2;
public:
	CRectangle(Point , Point,int, GfxInfo FigureGfxInfo );
	virtual void Draw(Output* pOut) const;
	virtual bool isThisFigure(Point p) const;  // Check is this the selected figure
	virtual void PrintInfo(Output* pOut);	//print all figure info on the status bar
	char keyshape();
};

#endif