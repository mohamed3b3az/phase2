#ifndef HEXA_H
#define HEXA_H
#include "Figures/CFigure.h"
class CHexa : public CFigure
{
private:
	Point Center;
public:
	CHexa(Point,int , GfxInfo FigureGfxInfo);
	virtual void Draw(Output* pOut) const;
	virtual bool isThisFigure(Point p) const ;  // Check is this the selected figure
	virtual void PrintInfo(Output* pOut);	//print all figure info on the status bar
	char keyshape();
};
#endif
